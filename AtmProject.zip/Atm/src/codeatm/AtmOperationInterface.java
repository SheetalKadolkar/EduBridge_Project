package codeatm;

public interface AtmOperationInterface {

	public void viewBalance(); 
	public void withdrawAmount(double withdrawAmoun);
	public void depositAmount(double depositAmount);
	public void viewMiniStatement();
	
	
}
