package codeatm;
import java.util.Scanner;
public class TestAtm {

	public static void main(String[] args) {
//object implementation class
		AtmOperationInterface op=new AtmOperationImpl();
		int atmnumber=1234;
		int atmpin=1020;
		Scanner sc=new Scanner(System.in);
		System.out.println("*** WELCOME TO ATM ***");
		System.out.println("Enter ATM NUMBER : ");
		int atmNumber=sc.nextInt();
		System.out.println("Enter ATM PIN:  ");
		int  atmPin=sc.nextInt();
		
		if((atmnumber==atmNumber) && (atmpin==atmPin))
		{
			while(true) {
				System.out.println("\n 1.View Balance \n 2.Withdraw Amount \n 3.Deposit Amount \n 4.View Ministatement \n 5.Exit");
				System.out.println("Enter Choice : ");
				int ch=sc.nextInt();
				if(ch==1) 
				{
				op.viewBalance();	
				}
				else if(ch==2)
				{
					System.out.println("Enter the amount to withdraw: ");
					double withdrawAmount=sc.nextDouble();
					op.withdrawAmount(withdrawAmount);
					
				}
				else if(ch==3)
				{
					System.out.println("Enter the amount to deposit: ");
					double depositAmount=sc.nextInt();	
					op.depositAmount(depositAmount);
				}
				else if(ch==4)
				{
					op.viewMiniStatement();
					
				}
				else if(ch==5)
				{
					System.out.println("Collect your ATM Card ");
					System.out.println("THANK YOU VISIT AGAIN !! ");
					System.exit(0);
				}
				else 
				{
					System.out.println("Please enter Correct Choice ");
				}
			}
		                //System.out.println("Validation Successfully  ");	
		}
		else
		{
		System.out.println("Incorrect ATM number or pin ");
		System.exit(0);
		}
	}

}
